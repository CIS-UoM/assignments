import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;

/**
 * See the comments for the server!
 * 
 * @author Nikolay
 * @author Adel
 *
 */
public class SSLTCPClient {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// You can hardcode the values of the JVM variables as follows:
		//System.setProperty("javax.net.ssl.trustStore", "<path-to-certificate>");
		//System.setProperty("javax.net.ssl.trustStorePassword","<password>");
		
		// Create SSL socket factory, which creates SSLSocket instances
		SocketFactory factory= SSLSocketFactory.getDefault();
		
		// Use the factory to instantiate SSLSocket
		try(Socket socket = factory.createSocket("localhost", 80)) {
			DataInputStream in = new DataInputStream(socket.getInputStream());
			DataOutputStream out = new DataOutputStream(socket.getOutputStream());
			
			out.writeUTF("Hello Server");
			out.flush();
			String msg = in.readUTF();
			System.out.println(msg);
		}
	}
}
