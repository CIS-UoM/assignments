This directory contains a few Bean programs, including gcd.bean from
the spec.  The milestone*.bean sequence correspond to the seven steps
suggested on page 13 of the spec.
